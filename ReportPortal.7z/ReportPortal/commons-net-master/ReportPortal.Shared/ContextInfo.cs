﻿namespace ReportPortal.Shared
{
    public class ContextInfo
    {
        /// <summary>
        /// Current reporter to send results.
        /// </summary>
        public LaunchReporter LaunchReporter { get; set; }
    }
}