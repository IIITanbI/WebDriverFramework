[![Build status](https://ci.appveyor.com/api/projects/status/thjw94949tm5lbw5/branch/master?svg=true)](https://ci.appveyor.com/project/nvborisenko/client-net/branch/master)
[![NuGet version](https://badge.fury.io/nu/reportportal.client.svg)](https://badge.fury.io/nu/reportportal.client)
